from setuptools import setup
from setuptools import find_packages

VERSION = '0.1.0'

with open('readme.md') as f:
    LONG_DESCRIPTION = f.read()

setup(
    name = 'pkg-example-jrx',
    version = VERSION,
    description = 'A packaging example',
    long_description = LONG_DESCRIPTION,
    long_description_content_type = 'text/markdown',
    author = 'jrx',
    author_email = 'jrx@some.where',
    url = 'http://somewhere.com',

    python_requires = '>=3.6',
    install_requires = [
        'requests>=2.19.0',
    ],

    package_dir = {'': 'src'},
    packages = find_packages('src'),
    package_data = {
        '': ['*.json'],
    },
)


