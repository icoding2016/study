<?php
// Custom Racktables Report v.0.3.3
// List all B2lab Devices

// 2019-12-04 - Mijith(mijith@google.com)

$tabhandler['reports']['b2lab'] = 'renderB2Report'; // register a report rendering function
$tab['reports']['b2lab'] = 'NetEng B2 Lab';                  // The title of the report tab

require_once "reportExtensionLib.php";


function filteredScanRealm ($Filter)
{
    $aResult = array();
    $iTotal = 0;
    foreach (scanRealmByText ('object', $Filter) as $Result)
    {
        $aResult[$Result['id']] = array();
        $aResult[$Result['id']]['sName'] = $Result['name'];
        $aResult[$Result['id']]['sLabel'] = $Result['label'];

        // Create active links in comment
        $aResult[$Result['id']]['sComment'] = makeLinksInText($Result['comment']);

        // Load additional attributes:
        $attributes = getAttrValues ($Result['id']);

        //Current User
        $aResult[$Result['id']]['CurrentUser'] = '';
        if ( isset( $attributes['10000']['a_value'] ) )
            $aResult[$Result['id']]['CurrentUser'] = $attributes['10000']['a_value'];


        //Start Date
        $aResult[$Result['id']]['StartDate'] = '';
        if ( isset( $attributes['10001']['value'] ) )
            $aResult[$Result['id']]['StartDate'] = date('Y-m-d', intval($attributes['10001']['value']));

        //End Date
        $aResult[$Result['id']]['EndDate'] = '';
        if ( isset( $attributes['10002']['value'] ) )
            $aResult[$Result['id']]['EndDate'] = date('Y-m-d', intval($attributes['10002']['value']));

        //Owner
        $aResult[$Result['id']]['sContact'] = '';
        if ( isset( $attributes['14']['a_value'] ) )
            $aResult[$Result['id']]['sContact'] = $attributes['14']['a_value'];        

        // Location
        $aResult[$Result['id']]['sLocation'] = getLocation($Result);

        // Purpose
        $aResult[$Result['id']]['sPurpose'] = '';
        if ( isset( $attributes['10003']['a_value'] ) )
            $aResult[$Result['id']]['sPurpose'] = $attributes['10003']['a_value'];

        // Reservable
        $aResult[$Result['id']]['uReservable'] = '';
        if ( isset( $attributes['10004']['a_value'] ) )
            $aResult[$Result['id']]['uReservable'] = $attributes['10004']['a_value'];

        $iTotal++;
    }
    $aResult['total_devices'] = $iTotal;
    return $aResult;
}


function renderB2Report()
{
    $aResult = array();
    $iTotal = 0;
    $sRFilter = '{$typeid_7}'; # typeid_7 = Routers
    $sSFilter = '{$typeid_8}'; # typeid_7 = Switches
    $aResult += filteredScanRealm ($sRFilter);
    $iTotal += $aResult['total_devices'];
    $aResult += filteredScanRealm ($sSFilter);
    $iTotal += $aResult['total_devices']; 

    if ( isset($_GET['csv']) ) {
        header('Content-type: text/csv');
        header('Content-Disposition: attachment; filename=export_'.date("Ymdhis").'.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $outstream = fopen("php://output", "w");

        $aCSVRow = array('Name','H/W Model','Current User','Start Date','End Date','Contact','Location','Purpose','Comment');

        fputcsv( $outstream, $aCSVRow );

        foreach ($aResult as $id => $aRow) {
            $aCSVRow = array();
            $aCSVRow[0] = $aRow['sName'];
            $aCSVRow[1] = $aRow['sLabel'];
            $aCSVRow[2] = $aRow['CurrentUser'];
            $aCSVRow[3] = $aRow['StartDate'];
            $aCSVRow[4] = $aRow['EndDate'];
            $aCSVRow[5] = $aRow['sContact'];
            $aCSVRow[6] = preg_replace('/<a[^>]*>(.*)<\/a>/iU', '$1', $aRow['sLocation']);
            $aCSVRow[7] = $aRow['sPurpose'];
            $aCSVRow[8] = str_replace('&quot;',"'",$aRow['sComment']);

	    fputcsv( $outstream, $aCSVRow );
        }
        fclose($outstream);

        exit(0); # Exit normally after send CSV to browser

    }

    if ( isset($_GET['csv_imp']) ) {
      importFromCSV();
    }
    
    // Load stylesheet and jquery scripts
    addCSS ('css/extensions/style.css');
    addJS ('js/extensions/jquery-latest.js');
    addJS ('js/extensions/jquery.tablesorter.js');
    addJS ('js/extensions/picnet.table.filter.min.js');

    // Display the stat array
    echo "<h2>B2 Lab Inventory have ($iTotal) devices</h2><ul>";

    echo '<a href="index.php?page=reports&tab=b2lab&csv">[CSV Export]</a>';
    echo "&nbsp";
    echo '<a href="index.php?page=reports&tab=b2lab&csv_imp" target="_blank">[CSV Import]</a>';

    echo '<table id="reportTable" class="tablesorter">
            <thead>
              <tr>
        <th>Device Name</th>
        <th>H/W Model</th>
                <th>Current User</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Managed by</th>
                <th>Location</th>
                <th>Purpose</th>
                <th>Comments</th>               
               </tr>
             </thead>
           <tbody>';

    foreach ($aResult as $id => $aRow)
    {
        echo '<tr>
        <td><a href="'. makeHref ( array( 'page' => 'object', 'object_id' => $id) )  .'">'.$aRow['sName'].'</a></td>
        <td>'.$aRow['sLabel'].'</td>
        <td>'.$aRow['CurrentUser'].'</td>
                <td>'.$aRow['StartDate'].'</td>
                <td>'.$aRow['EndDate'].'</td>
                <td>'.$aRow['sContact'].'</td>
                <td>'.$aRow['sLocation'].'</td>
                <td>'.$aRow['sPurpose'].'</td>
                <td>'.$aRow['sComment'].'</td>                
              </tr>';
    }

    echo '  </tbody>
          </table>';

    echo '<script type="text/javascript">
            $(document).ready(function()
              {
                $.tablesorter.defaults.widgets = ["zebra"];
                $("#reportTable").tablesorter(
                    { headers: {
                    }, sortList: [[0,0]] }
                );
                $("#reportTable").tableFilter();
              }
            );
          </script>';
}

function importFromCSV() {

  // import csv 
  echo "<table border=0 cellspacing=0 cellpadding=3 width='100%' align='center'>\n";
  echo "<form id='loadData' action='$_SERVER[_PHP_SELF]' method='post' enctype='multipart/form-data'>";
  echo "<h3>Select the csv file to import the B2Lab information into DB </h3><br>";
  echo "<input type='file' name='fileToUpload' id='fileToUpload'>";
  echo "<label><input type='checkbox' name='previewOnly' value='Yes' checked>Preview-Only</label>";
  echo "&nbsp&nbsp<input type='submit' name='loadCSV' value='Merge Data to DB'>";
  echo "</form>";
  echo "</table>";
  echo "<br><br>";

  echo "<style>";
  echo ".header { color:black; background-color:lightgrey }";
  echo ".normal { color:black; }";
  echo ".error { color:red; }";
  echo ".warning { color:brown; }";
  echo ".info { color:blue; }";
  echo ".weaken { color:rgb(150,150,150); }";
  echo ".highlight { background-color:yellow; }";
  echo "</style>";

  $csv_data = array();
  $db_objs = array();

  if (isset($_POST["loadCSV"])) {
    $csv_data = loadCSVIntoArray();
    if (empty($csv_data)) {
      exit(0);
    }
    $previewOnly = isset($_POST['previewOnly']) ? true : false;
    $db_objs = listCells('object');
    echo "<div>";
    if ($previewOnly) {
      mergeCSVDataToDB($csv_data, $db_objs, $write2db=false);
      echo "Merge preview completed.";
    } else {
      mergeCSVDataToDB($csv_data, $db_objs, $write2db=true);
      echo "Merge data to DB completed.";
      exit(0);
    }
    echo "</div>";
  }

  exit(0);
}


function loadCSVIntoArray() {
  $handle = fopen($_FILES["fileToUpload"]["tmp_name"], 'r') or die("Error reading file!");
  $csv_data = array();

  echo "Loading data ... ";
  while (($line = fgetcsv($handle)) !== false) {
    array_push($csv_data, $line);
  }
  fclose($handle);
  if (empty($csv_data)) {
    echo "<p class='error'> Fail to load CSV. </p><br>";
  }
  echo "Done.<br>";
  return $csv_data;
}


function mergeCSVDataToDB($csv_data, $db_objs, $write2db=false) {
  $csv2db_keys = array(  // csv header -> db key
    "name",  // "Device" => "name",
    "",  // "H/W Model" => "",     no need to merge/update to db
    "label",  // "NETLAB ID" => "label",
    "Current User",  // "Current User" => "Current User",
    "Start Date",  // "Start Date" => "Start Date",
    "End Date",  // "End Date" => "End Date",
    "contact person",  // "Team Contact" => "contact person",
    "Location",  // "Location" => "",  // getLocation($object);    no need to merge/update to db
    "Purpose",  // "Purpose" => "Purpose",
    "comment",  // "Notes" => "comment",
  );
  $csv2db_oprs = array (  // the operation from csv -> db
    "keep",
    "skip",
    "keep",
    "override",
    "override",
    "override",
    "override",   //"keep",  ??
    "keep",
    "override",
    "merge",
  );

  $csv_headers = array();
  $col_num = 0;
  $db_row = array();
  $merge_row = array();
  $obj_count = sizeof($csv_data);
  $obj_upd_count = 0;
  $col_upd_count = 0;
  $opr_result = "";
  $failure_log = "";
  $i = 0;

  echo "<p>The conflicts are marked in <span class='warning'>Dark-Red</span> and changes are <span class='highlight'>highlighted</span></p>";

  if ($write2db) {
    echo "<br><strong>Merge Result ... </strong> <label id='merge_result'>$opr_result</label><br>";
  } else {
    echo "<br><strong>Merge Preview ... </strong> <span><label id='merge_result'>$opr_result</label></span><br>";
  }

  echo "<table id='csv-merge' width='100%', border='1' cellspacing='0'>";  //class='tablesorter' 
  foreach ($csv_data as $line) {
    if ($i == 0) {    // Header line
      $csv_headers = $line;
      $col_num = sizeof($csv_headers);
      echo "<thead><tr class='header'>";
      echo "<th></td>";    // line#
      echo "<th></td>";    // Row info
      for ($j=0; $j<$col_num; $j++) {
        echo "<th>$csv_headers[$j]</td>";
      }
      echo "</tr><thead>";
      echo "<tbody class='normal'>";
      $i++;
    }
    else {        
      echo "<tr><td>$i</td>";    // line#
      $i++;
      // CSV content
      if (sizeof($line) != $col_num) {
        echo "<td class='error'>ERROR: csv row record count does not match header count $col_num.</td>";
        if (sizeof($line) > 1) {
          echo "<td>$line[0]</td>";
        }
        echo "</tr>";
        continue;
      }
      echo "<td>CSV</td>";
      for ($j=0; $j<$col_num; $j++) {
        echo nl2br("<td class='weaken'>$line[$j]</td>");
      }
      echo "</tr>";

      // DB content
      echo "<tr>";
      echo "<td>&nbsp</td>";    // line#
      $name = $line[0];
      $obj = findObjectByName($name, $db_objs);
      if (null == $obj) {
        echo "<td class='warning' colspan='$col_num'>Object $name not in DB, skip merging this record.</td></tr>";
        continue;
      }
      $csv_db_diff = array_fill(0, $col_num, false);
      for ($j=0; $j<$col_num; $j++)  {
        $value = getObjValue($obj, $csv2db_keys[$j]);
        $db_row[$j] = empty($value) ? "" : $value;        
        switch ($csv2db_oprs[$j]) {
          case "keep":
            $merge_row[$j] = $db_row[$j];
            break;
          case "skip":
            $merge_row[$j] = "";
            break;
          case "override":
            if (trim($db_row[$j]==trim($line[$j]))) {
              $merge_row[$j] = $db_row[$j];
            } else {
              $merge_row[$j] = $line[$j];
              $csv_db_diff[$j] = ($line[$j]!=$db_row[$j]) ? true : $csv_db_diff[$j];
            }
            break;
          case "merge":
            if (empty($line[$j])) {
              $merge_row[$j] = $db_row[$j];
            } elseif (empty($db_row[$j])) {
              $merge_row[$j] = $line[$j];
            } elseif (trim($db_row[$j]==trim($line[$j]))) {
              $merge_row[$j] = $db_row[$j];
            } else {
              $merge_row[$j] = $db_row[$j] . "\n\n" . $line[$j];
              $csv_db_diff[$j] = true;
            }
            break;
        }
        // $csv_db_diff[$j] = (!empty($line[$j]) and !empty($db_row[$j]) and $line[$j]!=$db_row[$j]) ? true : $csv_db_diff[$j];
      }
      echo "<td>DB</td>";
      for ($j=0; $j<$col_num; $j++) {
        if ($csv_db_diff[$j]) {
          echo nl2br("<td class='warning'>$db_row[$j]</td>");
        } else {
          echo nl2br("<td class='weaken'>$db_row[$j]</td>");
        }
      }
      echo "</tr>";

      // Merge result
      $obj_has_update = false;
      $obj_new_data = array();
      echo "<tr>";
      echo "<td>&nbsp</td>";    // line#
      echo "<td>MERGE>></td>";
      for ($j=0; $j<$col_num; $j++) {
        if ($db_row[$j] == $merge_row[$j]) {
          echo nl2br("<td class='default'>$merge_row[$j]</td>");  
        } else {
          $obj_new_data += array($csv2db_keys[$j]=>$merge_row[$j]);
          
          echo nl2br("<td class='info highlight'>$merge_row[$j]</td>");  
          $col_upd_count += 1;
          $obj_has_update = true;
        }
      }
      if ($write2db and $obj_has_update) {
        if (!updateDBRecord($obj, $obj_new_data)) {
          $failure_log = $failure_log . "Update object failed. " . $obj['name'] ."\n";
        }
      }
      $obj_upd_count += $obj_has_update ? 1 : 0;
      echo "</tr>";
    }
    echo "</tbody>";
  }
  echo "</table>";
  $opr_result = "Done. ($obj_count objects checked; $obj_upd_count objects / $col_upd_count attributes updated)";
  echo "<label for='merge_result'> <strong>Done. ($obj_count objects checked; $obj_upd_count objects / $col_upd_count attributes updated)</strong></label>";
  echo nl2br("<p class='error'>$failure_log</p>");

}

function updateDBRecord($curobj, $newdata) {
	//setFuncMessages (__FUNCTION__, array ('OK' => 51));

	$object_id = $curobj['id'];

	$attr_ids = array (
    'contact person' => 14,
		'Current User' => 10000,
		'Start Date' => 10001,
		'End Date' => 10002,
		'Purpose' => 10003,
	);
  $obj_info_items = array (
    'name',
    'label',
    'asset_no',
    'comment',
  );

  $new_obj_data = array();
  $attr_values = array();
  foreach ($newdata as $key => $value) {
    if (!in_array($key, $obj_info_items) and !in_array($key, $attr_ids)) {
      assert(true, "Data $key=>$value is not found in supported list.");
    }
    if (in_array($key, $obj_info_items)) {
      $new_obj_data += array($key => $value);
    } 
    if (array_key_exists($key, $attr_ids)) {
      if (in_array($key, array('Start Date', 'End Date'))) {
        $value = strtotime($value);
      }
      $attr_values += array($attr_ids[$key] => $value);
    }
  }

	global $dbxlink;
	$dbxlink->beginTransaction();
  if (count($new_obj_data)) {
    commitUpdateObject
    (
      $object_id,
      isset($new_obj_data['name']) ? $new_obj_data['name'] : $curobj['name'],
      isset($new_obj_data['label']) ? $new_obj_data['label'] : $curobj['label'],
      isset($new_obj_data['has_problems']) ? $new_obj_data['has_problems'] : $curobj['has_problems'],
      isset($new_obj_data['asset_no']) ? $new_obj_data['asset_no'] : $curobj['asset_no'],
      isset($new_obj_data['comment']) ? $new_obj_data['comment'] : $curobj['comment'],
    );
  }
  foreach ($attr_values as $id => $value) {
    commitUpdateAttrValue ($object_id, $id, $value);
  }
  $dbxlink->commit();
	//showFuncMessage (__FUNCTION__, 'OK');
  return true;
}


function findObjectByName($name, $objlist) {
  if (empty($name)) {
    return null;
  }
  foreach ($objlist as $obj) {
    if ($name == $obj['name']) {
      return $obj;
    }
  }
  return null;
}

function getObjValue($obj, $keyword) {
  global $SQLSchema;

  if (empty($obj) or empty($keyword)) {
    return null;
  }

  if (in_array($keyword, $SQLSchema['object']['columns'])) {
    return $obj[$keyword];
  }
  $keyword = strtolower($keyword);
  if ($keyword == 'location') {
    return getLocation($obj);
  }
  if (in_array($keyword, array('current user', 'start date', 'end date', 'purpose', 'contact person'))) {
    $attributes = getAttrValues ($obj['id']);
    switch ($keyword) {
      case 'current user':
        return $attributes['10000']['value'];
      case 'start date':
        return isset($attributes['10001']['value']) ? date('Y/m/d', intval($attributes['10001']['value'])) : "";
      case 'end date':
        return isset($attributes['10002']['value']) ? date('Y/m/d', intval($attributes['10002']['value'])) : "";
      case 'purpose':
        return $attributes['10003']['value'];
      case 'contact person':
        return $attributes['14']['value'];
      }
  }

  return null;
}

